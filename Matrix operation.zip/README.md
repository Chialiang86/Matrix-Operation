編譯方式：

    g++ -o Matrix Matrix.cpp

執行方式(Windows)

    1.使用example.txt

        Matrix.exe < example.txt

    2.自行輸入

        Matrix.exe

執行方式(Linux or Mac)

    1.使用example.txt

        ./Matrix < example.txt

    2.自行輸入

        ./Matrix




    
